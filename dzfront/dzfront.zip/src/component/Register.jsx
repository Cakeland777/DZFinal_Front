
import React from 'react';

const Register = () => {
  return (
    <div>
      <h2>회원가입</h2>
      
    </div>
  );
};

export default Register;
